# Zyvor AI Chat

Website chat AI sederhana untuk Vercel, dibuat dengan HTML/CSS/JS dan endpoint proxy serverless.

## Deploy dari HP Android
1. Upload `index.html`, `vercel.json`, `README.md`, dan folder `api` beserta `api/chat.js` ke root repository GitHub.
2. Import repository itu di Vercel atau push perubahan ke repository yang sudah terhubung.
3. Framework preset: Other. Build command dan output directory bisa dikosongkan.
4. Buka URL deployment Vercel dan coba kirim pesan.

## API
Frontend memanggil `/api/chat`. Function di `api/chat.js` meneruskan parameter `message`, `model`, dan `conversation_id` ke API Zyvor dari server, sehingga browser tidak memanggil upstream langsung.

Catatan:
- Website ini mengasumsikan API upstream menerima GET dan mengembalikan JSON atau teks.
- Nama field balasan bisa berbeda; frontend mencoba field umum seperti `reply`, `response`, `answer`, `result`, dan `choices[0].message.content`. Kalau format API berbeda, tampilannya akan menunjukkan JSON mentah agar mudah diperiksa.
- Endpoint publik dapat memiliki batas penggunaan dan waktu respons sendiri. Proxy tidak bisa memperbaiki gangguan di sisi upstream.
