
export default async function handler(req, res) {
  if (req.method !== "POST") {
    res.setHeader("Allow", "POST");
    return res.status(405).json({ error: "Method not allowed" });
  }

  const apiKey = process.env.XKIRO_API_KEY;

  if (!apiKey) {
    return res.status(500).json({
      error: "XKIRO_API_KEY belum dipasang di Vercel Environment Variables."
    });
  }

  try {
    const { model, messages } = req.body || {};

    if (typeof model !== "string" || !model.trim()) {
      return res.status(400).json({ error: "Model tidak valid." });
    }

    if (!Array.isArray(messages) || !messages.length || messages.length > 80) {
      return res.status(400).json({ error: "Riwayat pesan tidak valid." });
    }

    const cleanMessages = [];

    for (const message of messages) {
      if (
        !message ||
        !["user", "assistant"].includes(message.role) ||
        typeof message.content !== "string"
      ) {
        return res.status(400).json({ error: "Format pesan tidak valid." });
      }

      cleanMessages.push({
        role: message.role,
        content: message.content.slice(0, 30000)
      });
    }

    if (cleanMessages[cleanMessages.length - 1].role !== "user") {
      return res.status(400).json({
        error: "Pesan terakhir harus berasal dari pengguna."
      });
    }

    const response = await fetch(
      "https://api.xkiro.com/v1/chat/completions",
      {
        method: "POST",
        headers: {
          "Authorization": `Bearer ${apiKey}`,
          "Content-Type": "application/json",
          "Accept": "application/json"
        },
        body: JSON.stringify({
          model,
          messages: cleanMessages,
          stream: false
        }),
        signal: AbortSignal.timeout(90000)
      }
    );

    const data = await response.json().catch(() => ({}));

    if (!response.ok) {
      return res.status(response.status).json({
        error: data?.error?.message ||
          data?.message ||
          `xKiro API error (${response.status})`
      });
    }

    return res.status(200).json(data);
  } catch (error) {
    if (
      error?.name === "TimeoutError" ||
      error?.name === "AbortError"
    ) {
      return res.status(504).json({
        error: "Request timeout. Coba model yang lebih cepat."
      });
    }

    return res.status(502).json({
      error: "Backend gagal menghubungi xKiro."
    });
  }
}
