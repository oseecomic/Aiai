
export default async function handler(req, res) {
  if (req.method !== "GET") {
    res.setHeader("Allow", "GET");
    return res.status(405).json({ error: "Method not allowed" });
  }

  try {
    const response = await fetch(
      "https://api.xkiro.com/v1/models",
      { signal: AbortSignal.timeout(15000) }
    );

    const data = await response.json().catch(() => ({}));

    res.setHeader(
      "Cache-Control",
      "s-maxage=300, stale-while-revalidate=600"
    );

    return res.status(response.status).json(data);
  } catch {
    return res.status(502).json({
      error: "Tidak dapat mengambil daftar model dari xKiro."
    });
  }
}
