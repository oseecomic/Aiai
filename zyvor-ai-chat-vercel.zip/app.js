
(() => {
  const $ = id => document.getElementById(id);
  const STORE = "osee_xkiro_threads";
  const MODEL_STORE = "osee_xkiro_model";

  let threads = [];
  try {
    threads = JSON.parse(localStorage.getItem(STORE) || "[]");
  } catch {}
  if (!Array.isArray(threads)) threads = [];

  const makeId = () => "t" + Date.now().toString(36) +
    Math.random().toString(36).slice(2, 6);

  let activeId = threads[0]?.id || makeId();
  let busy = false;
  let models = [];

  function currentThread() {
    let thread = threads.find(t => t.id === activeId);
    if (!thread) {
      thread = {
        id: activeId,
        title: "New conversation",
        messages: [],
        updated: Date.now()
      };
      threads.unshift(thread);
    }
    return thread;
  }

  function save() {
    try {
      localStorage.setItem(STORE, JSON.stringify(threads.slice(0, 40)));
    } catch {}
  }

  function escapeHTML(value) {
    return String(value).replace(/[&<>"]/g, char => ({
      "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;"
    })[char]);
  }

  function notify(message) {
    const toast = $("toast");
    toast.textContent = message;
    toast.style.display = "block";
    clearTimeout(notify.timer);
    notify.timer = setTimeout(() => toast.style.display = "none", 3000);
  }

  function render() {
    const thread = currentThread();
    $("welcome").hidden = thread.messages.length > 0;

    $("messages").innerHTML = thread.messages.map(message => `
      <article class="message ${message.role}">
        <div class="avatar">${message.role === "user" ? "Y" : "O"}</div>
        <div class="body">
          <div class="meta">${escapeHTML(
            message.role === "user" ? "YOU" : message.modelLabel || "OSEE AI"
          )}</div>
          <div class="text">${escapeHTML(message.content)}</div>
        </div>
      </article>
    `).join("");

    $("history").innerHTML = threads
      .slice()
      .sort((a, b) => b.updated - a.updated)
      .map(thread => `
        <button class="${thread.id === activeId ? "active" : ""}"
          data-id="${escapeHTML(thread.id)}">
          ◇ ${escapeHTML(thread.title || "New conversation")}
        </button>
      `).join("");

    $("history").querySelectorAll("button").forEach(button => {
      button.onclick = () => {
        activeId = button.dataset.id;
        render();
        $("sidebar").classList.remove("open");
      };
    });

    $("area").scrollTop = $("area").scrollHeight;
    save();
  }

  async function loadModels() {
    try {
      const response = await fetch("/api/models");
      const data = await response.json();
      if (!response.ok) throw new Error(data.error || "Gagal memuat model");

      models = (data.data || []).filter(
        model => model && typeof model.id === "string"
      );

      if (!models.length) throw new Error("Daftar model kosong");

      models.sort((a, b) =>
        (a.access_tier === "free" ? 0 : 1) -
        (b.access_tier === "free" ? 0 : 1)
      );

      $("model").innerHTML = models.map(model => `
        <option value="${escapeHTML(model.id)}">
          ${escapeHTML(
            (model.display_name || model.id) +
            (model.access_tier ? " · " + model.access_tier.toUpperCase() : "")
          )}
        </option>
      `).join("");

      const savedModel = localStorage.getItem(MODEL_STORE);
      if (models.some(model => model.id === savedModel)) {
        $("model").value = savedModel;
      }
    } catch (error) {
      $("model").innerHTML = '<option value="">Model unavailable</option>';
      notify(error.message);
    }
  }

  async function send() {
    if (busy) return;

    const input = $("input");
    const content = input.value.trim();
    const model = $("model").value;

    if (!content) return;
    if (!model) return notify("Model belum tersedia.");

    const thread = currentThread();
    thread.messages.push({ role: "user", content });
    thread.updated = Date.now();

    if (thread.messages.filter(m => m.role === "user").length === 1) {
      thread.title = content.slice(0, 42) +
        (content.length > 42 ? "…" : "");
    }

    input.value = "";
    input.style.height = "auto";
    busy = true;
    $("send").disabled = true;
    $("typing").hidden = false;
    render();

    try {
      const response = await fetch("/api/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model,
          messages: thread.messages.map(m => ({
            role: m.role,
            content: m.content
          }))
        })
      });

      const data = await response.json().catch(() => ({
        error: "Respons server tidak valid"
      }));

      if (!response.ok) {
        throw new Error(data.error || "Request gagal (" + response.status + ")");
      }

      let answer = data?.choices?.[0]?.message?.content;

      if (Array.isArray(answer)) {
        answer = answer.map(part => part.text || "").join("");
      }

      if (typeof answer !== "string" || !answer.trim()) {
        throw new Error("Respons model kosong");
      }

      thread.messages.push({
        role: "assistant",
        content: answer,
        modelLabel: models.find(m => m.id === model)?.display_name || model
      });
    } catch (error) {
      thread.messages.push({
        role: "assistant",
        content: "Gagal menghubungi xKiro: " + error.message +
          "\nPeriksa API key, akses model, dan deployment Vercel."
      });
    } finally {
      busy = false;
      $("send").disabled = false;
      $("typing").hidden = true;
      thread.updated = Date.now();
      render();
      input.focus();
    }
  }

  function newChat() {
    activeId = makeId();
    threads.unshift({
      id: activeId,
      title: "New conversation",
      messages: [],
      updated: Date.now()
    });
    render();
    $("input").focus();
  }

  $("new").onclick = newChat;
  $("send").onclick = send;
  $("menu").onclick = () => $("sidebar").classList.toggle("open");

  $("input").oninput = event => {
    event.target.style.height = "auto";
    event.target.style.height =
      Math.min(event.target.scrollHeight, 150) + "px";
  };

  $("input").onkeydown = event => {
    if (event.key === "Enter" && !event.shiftKey) {
      event.preventDefault();
      send();
    }
  };

  $("model").onchange = () =>
    localStorage.setItem(MODEL_STORE, $("model").value);

  document.querySelectorAll("[data-p]").forEach(button => {
    button.onclick = () => {
      $("input").value = button.dataset.p;
      $("input").focus();
    };
  });

  if (!threads.length) {
    threads = [{
      id: activeId,
      title: "New conversation",
      messages: [],
      updated: Date.now()
    }];
  }

  render();
  loadModels();
})();
